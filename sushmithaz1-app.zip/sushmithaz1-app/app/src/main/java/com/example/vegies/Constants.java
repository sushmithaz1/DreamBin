package com.example.vegies;

public class Constants {
   public static final String[] productCategories={
            "Vegetables",
            "Fruits",

    };
    public static final String[] productCategories1={
            "Vegetables",
            "Fruits",

    };


}
