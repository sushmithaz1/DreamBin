package com.example.vegies.adapter;

import androidx.recyclerview.widget.RecyclerView;

abstract class AdapterCart1 extends RecyclerView.Adapter<AdapterCart.HolderCart> {
}
